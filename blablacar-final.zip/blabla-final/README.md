```
blabla/
├── app.js                        ← Entry point
├── .env                          ← Environment variables
├── package.json
│
├── models/
│   ├── User.js                   ← User schema (passenger/driver/both)
│   ├── Ride.js                   ← Ride schema with coordinates
│   └── Booking.js                ← Booking schema with payment status
│
├── controllers/
│   ├── authController.js         ← Signup, login, logout
│   ├── profileController.js      ← View, edit profile, my rides, my bookings
│   ├── rideController.js         ← List, create, detail, cancel rides
│   └── bookingController.js      ← Create, cancel booking, confirm payment
│
├── routes/
│   ├── indexRoutes.js            ← Home page
│   ├── authRoutes.js             ← /auth/*
│   ├── profileRoutes.js          ← /profile/*
│   ├── rideRoutes.js             ← /rides/*
│   └── bookingRoutes.js          ← /bookings/*
│
├── middlewares/
│   ├── authMiddleware.js         ← isAuthenticated, isDriver, isGuest
│   └── uploadMiddleware.js       ← Multer config for profile images
│
├── views/
│   ├── partials/
│   │   ├── header.ejs            ← Navbar + flash messages
│   │   └── footer.ejs            ← Footer
│   ├── index.ejs                 ← Landing page
│   ├── 404.ejs
│   ├── error.ejs
│   ├── auth/
│   │   ├── signup.ejs
│   │   └── login.ejs
│   ├── profile/
│   │   ├── view.ejs              ← Dashboard
│   │   ├── edit.ejs              ← Edit profile + vehicle info
│   │   ├── my-bookings.ejs       ← Passenger bookings
│   │   └── my-rides.ejs          ← Driver rides + passengers list
│   └── rides/
│       ├── list.ejs              ← Search & filter rides
│       ├── details.ejs           ← Ride detail + booking widget + map
│       └── new.ejs               ← Publish ride form
│
└── public/
    ├── css/style.css             ← Full design system
    ├── js/main.js                ← Client-side JS
    └── images/
        ├── default-avatar.png
        └── uploads/              ← User uploaded profile images
```

