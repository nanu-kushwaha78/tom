// ─── ES Module: routes/indexRoutes.js ─────────────────────────────────────
import { Router } from 'express';

const router = Router();

router.get('/', (req, res) => {
  res.render('index', { title: 'BlaBla — Share the Ride' });
});

export default router;
