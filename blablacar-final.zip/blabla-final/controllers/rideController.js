// ─── ES Module: controllers/rideController.js ─────────────────────────────
import Ride    from '../models/Ride.js';
import Booking from '../models/Booking.js';
import { emitRideUpdate, getIO } from '../socket.js';

// GET /rides
export const getAllRides = async (req, res, next) => {
  try {
    const { from, to, date, maxPrice, seats } = req.query;
    const filter = { status: 'active', availableSeats: { $gte: 1 } };

    if (from)     filter['source.name']      = { $regex: from, $options: 'i' };
    if (to)       filter['destination.name'] = { $regex: to,   $options: 'i' };
    if (date) {
      const d = new Date(date), nxt = new Date(d);
      nxt.setDate(nxt.getDate() + 1);
      filter.date = { $gte: d, $lt: nxt };
    }
    if (maxPrice) filter.price          = { $lte: Number(maxPrice) };
    if (seats)    filter.availableSeats = { $gte: Number(seats) };

    const rides = await Ride.find(filter)
      .populate('driver', 'name profileImage rating')
      .sort({ date: 1 });

    res.render('rides/list', {
      title: 'Find a Ride', rides, query: req.query
    });
  } catch (err) { next(err); }
};

// GET /rides/new
export const getNewRide = (req, res) => {
  res.render('rides/new', { title: 'Publish a Ride' });
};

// POST /rides
export const createRide = async (req, res) => {
  try {
    const {
      sourceName, destinationName,
      date, time, price, seats, description
    } = req.body;

    const ride = await Ride.create({
      driver:      req.session.userId,
      source:      { name: sourceName },
      destination: { name: destinationName },
      date: new Date(date), time,
      price: Number(price),
      totalSeats: Number(seats), availableSeats: Number(seats),
      description
    });

    // Broadcast new ride to everyone on the rides list page
    const io = getIO();
    if (io) {
      const populated = await ride.populate('driver', 'name profileImage rating');
      io.emit('ride:new', {
        _id:           ride._id.toString(),
        source:        ride.source,
        destination:   ride.destination,
        date:          ride.date,
        time:          ride.time,
        price:         ride.price,
        availableSeats: ride.availableSeats,
        driver: {
          name:         populated.driver.name,
          profileImage: populated.driver.profileImage,
          rating:       populated.driver.rating
        }
      });
    }

    req.flash('success', 'Ride published successfully! 🎉');
    res.redirect(`/rides/${ride._id}`);
  } catch (err) {
    req.flash('error', err.message);
    res.redirect('/rides/new');
  }
};

// GET /rides/:id
export const getRideDetails = async (req, res, next) => {
  try {
    const ride = await Ride.findById(req.params.id)
      .populate('driver', 'name profileImage rating phone bio vehicle');
    if (!ride) {
      req.flash('error', 'Ride not found.');
      return res.redirect('/rides');
    }

    let userBooking = null;
    if (req.session.userId) {
      userBooking = await Booking.findOne({
        ride: ride._id, passenger: req.session.userId,
        bookingStatus: { $in: ['pending', 'confirmed'] }
      });
    }

    res.render('rides/details', {
      title: `${ride.source.name} → ${ride.destination.name}`,
      ride, userBooking
    });
  } catch (err) { next(err); }
};

// DELETE /rides/:id
export const cancelRide = async (req, res) => {
  try {
    const ride = await Ride.findById(req.params.id);
    if (!ride) {
      req.flash('error', 'Ride not found.');
      return res.redirect('/profile/my-rides');
    }
    if (ride.driver.toString() !== req.session.userId.toString()) {
      req.flash('error', 'Unauthorized action.');
      return res.redirect('/profile/my-rides');
    }

    ride.status = 'cancelled';
    await ride.save();

    await Booking.updateMany(
      { ride: ride._id, bookingStatus: { $in: ['pending', 'confirmed'] } },
      { bookingStatus: 'cancelled', cancelledBy: 'driver', cancelledAt: new Date(), paymentStatus: 'refunded' }
    );

    // ── Socket: broadcast cancellation to all watchers ────────────────
    emitRideUpdate(ride._id.toString(), { status: 'cancelled', availableSeats: 0 });

    req.flash('success', 'Ride cancelled. All passengers have been notified.');
    res.redirect('/profile/my-rides');
  } catch (err) {
    req.flash('error', err.message);
    res.redirect('/profile/my-rides');
  }
};
