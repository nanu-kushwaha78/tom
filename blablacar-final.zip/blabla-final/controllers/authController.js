// ─── ES Module: controllers/authController.js ─────────────────────────────
import User from '../models/User.js';

// GET /auth/signup
export const getSignup = (req, res) => {
  res.render('auth/signup', { title: 'Sign Up' });
};

// POST /auth/signup
export const postSignup = async (req, res) => {
  try {
    const { name, email, password, confirmPassword } = req.body;

    if (password !== confirmPassword) {
      req.flash('error', 'Passwords do not match.');
      return res.redirect('/auth/signup');
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      req.flash('error', 'Email already registered. Please log in.');
      return res.redirect('/auth/signup');
    }

    const user = await User.create({ name, email, password });

    req.session.userId = user._id;
    req.session.user   = { name: user.name, profileImage: user.profileImage };

    req.flash('success', `Welcome to BlaBla, ${user.name}! 🚗`);
    res.redirect('/profile');
  } catch (err) {
    req.flash('error', err.message);
    res.redirect('/auth/signup');
  }
};

// GET /auth/login
export const getLogin = (req, res) => {
  res.render('auth/login', { title: 'Login' });
};

// POST /auth/login
export const postLogin = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      req.flash('error', 'Invalid email or password.');
      return res.redirect('/auth/login');
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      req.flash('error', 'Invalid email or password.');
      return res.redirect('/auth/login');
    }

    req.session.userId = user._id;
    req.session.user   = { name: user.name, profileImage: user.profileImage };

    req.flash('success', `Welcome back, ${user.name}!`);
    res.redirect('/profile');
  } catch (err) {
    req.flash('error', err.message);
    res.redirect('/auth/login');
  }
};

// POST /auth/logout
export const logout = (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
};
