// ─── ES Module: controllers/profileController.js ──────────────────────────
import User    from '../models/User.js';
import Booking from '../models/Booking.js';
import Ride    from '../models/Ride.js';
import { existsSync, unlinkSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = dirname(__filename);

// GET /profile
export const getProfile = async (req, res, next) => {
  try {
    const user     = await User.findById(req.session.userId).lean();
    const bookings = await Booking.find({ passenger: user._id, bookingStatus: 'confirmed' })
      .populate('ride').sort({ createdAt: -1 }).limit(5);
    const rides    = await Ride.find({ driver: user._id, status: 'active' }).sort({ date: 1 }).limit(5);

    res.render('profile/view', { title: 'My Profile', user, bookings, rides });
  } catch (err) {
    next(err);
  }
};

// GET /profile/edit
export const getEditProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.session.userId).lean();
    res.render('profile/edit', { title: 'Edit Profile', user });
  } catch (err) {
    next(err);
  }
};

// PUT /profile/edit
export const updateProfile = async (req, res) => {
  try {
    const { name, phone, bio, vehicleBrand, vehicleModel, vehicleColor, vehiclePlate } = req.body;

    const updateData = {
      name, phone, bio,
      vehicle: {
        brand:       vehicleBrand,
        model:       vehicleModel,
        color:       vehicleColor,
        plateNumber: vehiclePlate
      }
    };

    if (req.file) {
      const oldUser = await User.findById(req.session.userId);
      if (oldUser.profileImage !== 'default-avatar.png') {
        const oldPath = join(__dirname, '../public/images/uploads', oldUser.profileImage);
        if (existsSync(oldPath)) unlinkSync(oldPath);
      }
      updateData.profileImage = req.file.filename;
    }

    const user = await User.findByIdAndUpdate(req.session.userId, updateData, { new: true, runValidators: true });

    req.session.user = { name: user.name, profileImage: user.profileImage };

    req.flash('success', 'Profile updated successfully!');
    res.redirect('/profile');
  } catch (err) {
    req.flash('error', err.message);
    res.redirect('/profile/edit');
  }
};

// GET /profile/my-bookings
export const getMyBookings = async (req, res, next) => {
  try {
    const bookings = await Booking.find({ passenger: req.session.userId })
      .populate({ path: 'ride', populate: { path: 'driver', select: 'name profileImage rating' } })
      .sort({ createdAt: -1 });

    res.render('profile/my-bookings', { title: 'My Bookings', bookings });
  } catch (err) {
    next(err);
  }
};

// GET /profile/my-rides
export const getMyRides = async (req, res, next) => {
  try {
    const rides = await Ride.find({ driver: req.session.userId }).sort({ date: -1 });
    const ridesWithBookings = await Promise.all(rides.map(async (ride) => {
      const bookings = await Booking.find({ ride: ride._id, bookingStatus: 'confirmed' })
        .populate('passenger', 'name email profileImage phone');
      return { ...ride.toObject(), bookings };
    }));

    res.render('profile/my-rides', { title: 'My Rides', rides: ridesWithBookings });
  } catch (err) {
    next(err);
  }
};
