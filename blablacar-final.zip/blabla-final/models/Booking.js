// ─── ES Module: models/Booking.js ──────────────────────────────────────────
import mongoose from 'mongoose';

const bookingSchema = new mongoose.Schema({
  ride: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Ride',
    required: true
  },
  passenger: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  seatsBooked: {
    type: Number,
    required: true,
    min: 1
  },
  totalAmount: {
    type: Number,
    required: true
  },
  paymentMethod: {
    type: String,
    enum: ['cash', 'online'],
    required: true
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'paid', 'failed', 'refunded'],
    default: 'pending'
  },
  // 'pending' = awaiting driver approval (NEW)
  // 'confirmed' = driver accepted
  // 'rejected' = driver rejected
  // 'cancelled' = cancelled after confirmation
  bookingStatus: {
    type: String,
    enum: ['pending', 'confirmed', 'rejected', 'cancelled'],
    default: 'pending'
  },
  cancelledAt:  { type: Date },
  cancelledBy:  { type: String, enum: ['passenger', 'driver'] },
  respondedAt:  { type: Date },
  razorpayOrderId:   { type: String },
  razorpayPaymentId: { type: String }
}, { timestamps: true });

const Booking = mongoose.model('Booking', bookingSchema);
export default Booking;
