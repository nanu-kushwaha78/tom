// ─── ES Module: socket.js — Socket.IO event hub ───────────────────────────
//
// Room naming:
//   ride:<rideId>   – all clients watching a ride page
//   user:<userId>   – private channel per logged-in user
//
// Server → Client events:
//   ride:update        { rideId, status, availableSeats }
//   booking:newRequest { bookingId, passengerName, passengerImg,
//                        seatsBooked, totalAmount, paymentMethod,
//                        rideId, source, destination }
//   booking:response   { bookingId, status }   (sent to passenger)
//   notification:count { count }               (pending request badge)

let _io = null;

/** Attach the Socket.IO server instance (called from app.js) */
export function attachSocket(io) {
  _io = io;

  io.on('connection', (socket) => {
    // ── Join a ride room ───────────────────────────────────────────
    socket.on('joinRide', (rideId) => {
      socket.join(`ride:${rideId}`);
    });

    // ── Join personal user room ────────────────────────────────────
    socket.on('joinUser', (userId) => {
      if (userId) socket.join(`user:${userId}`);
    });

    socket.on('disconnect', () => {});
  });
}

/** Get the io instance (used in controllers to emit) */
export function getIO() {
  return _io;
}

// ── Helpers controllers can import and call ────────────────────────────────

/** Broadcast a ride status / seat change to everyone watching that ride */
export function emitRideUpdate(rideId, payload) {
  if (!_io) return;
  _io.to(`ride:${rideId}`).emit('ride:update', { rideId, ...payload });
}

/** Send a new booking request notification to the driver */
export function emitBookingRequest(driverUserId, payload) {
  if (!_io) return;
  _io.to(`user:${driverUserId}`).emit('booking:newRequest', payload);
}

/** Send accept/reject decision back to the passenger */
export function emitBookingResponse(passengerUserId, bookingId, status) {
  if (!_io) return;
  _io.to(`user:${passengerUserId}`).emit('booking:response', { bookingId, status });
}

/** Update the pending-requests badge count for a driver */
export function emitNotificationCount(driverUserId, count) {
  if (!_io) return;
  _io.to(`user:${driverUserId}`).emit('notification:count', { count });
}
