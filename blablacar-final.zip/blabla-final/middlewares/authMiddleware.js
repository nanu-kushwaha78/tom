// ─── ES Module: middlewares/authMiddleware.js ──────────────────────────────

// Protect routes - must be logged in
export const isAuthenticated = (req, res, next) => {
  if (req.session.userId) return next();
  req.flash('error', 'Please log in to continue.');
  res.redirect('/auth/login');
};

// All authenticated users can publish rides (role removed)
export const isDriver = (req, res, next) => {
  return next();
};

// Redirect logged-in users away from auth pages
export const isGuest = (req, res, next) => {
  if (!req.session.userId) return next();
  res.redirect('/profile');
};
