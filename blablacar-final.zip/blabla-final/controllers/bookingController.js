// ─── ES Module: controllers/bookingController.js ──────────────────────────
import Razorpay from 'razorpay';
import crypto   from 'crypto';
import Booking  from '../models/Booking.js';
import Ride     from '../models/Ride.js';
import User     from '../models/User.js';
import {
  emitRideUpdate,
  emitBookingRequest,
  emitBookingResponse,
  emitNotificationCount
} from '../socket.js';

// ── Razorpay instance ───────────────────────────────────────────────────────
const razorpay = new Razorpay({
  key_id:     process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

// ── Helper: push pending count badge to driver ──────────────────────────────
async function pushPendingCount(driverUserId) {
  const myRideIds = await Ride.find({ driver: driverUserId }).distinct('_id');
  const count = await Booking.countDocuments({
    ride: { $in: myRideIds },
    bookingStatus: 'pending'
  });
  emitNotificationCount(driverUserId.toString(), count);
}

// ── POST /bookings ───────────────────────────────────────────────────────────
export const createBooking = async (req, res) => {
  try {
    const { rideId, seats, paymentMethod } = req.body;
    const ride = await Ride.findById(rideId).populate('driver', 'name profileImage');

    if (!ride || ride.status !== 'active') {
      req.flash('error', 'Ride is no longer available.');
      return res.redirect('/rides');
    }
    if (ride.driver._id.toString() === req.session.userId.toString()) {
      req.flash('error', 'You cannot book your own ride.');
      return res.redirect(`/rides/${rideId}`);
    }

    // Only block if there's an active (pending/confirmed) booking
    // A failed/cancelled online booking should allow retry
    const existing = await Booking.findOne({
      ride: rideId,
      passenger: req.session.userId,
      bookingStatus: { $in: ['pending', 'confirmed'] }
    });
    if (existing) {
      req.flash('error', existing.bookingStatus === 'pending'
        ? 'Your booking request is already pending approval.'
        : 'You have already booked this ride.');
      return res.redirect(`/rides/${rideId}`);
    }

    const seatsBooked = Number(seats);
    if (seatsBooked > ride.availableSeats) {
      req.flash('error', `Only ${ride.availableSeats} seat(s) available.`);
      return res.redirect(`/rides/${rideId}`);
    }

    const totalAmount = seatsBooked * ride.price;

    // ── Cash path ────────────────────────────────────────────────────────
    if (paymentMethod === 'cash') {
      const booking = await Booking.create({
        ride: rideId, passenger: req.session.userId,
        seatsBooked, totalAmount,
        paymentMethod, paymentStatus: 'pending',
        bookingStatus: 'pending'
      });

      const passenger = await User.findById(req.session.userId).select('name profileImage');
      emitBookingRequest(ride.driver._id.toString(), {
        bookingId: booking._id.toString(), passengerName: passenger.name,
        passengerImg: passenger.profileImage, seatsBooked, totalAmount,
        paymentMethod, rideId: rideId.toString(),
        source: ride.source.name, destination: ride.destination.name
      });
      await pushPendingCount(ride.driver._id);

      req.flash('success', '🕐 Booking request sent! Waiting for driver approval.');
      return res.redirect('/profile/my-bookings');
    }

    // ── Online / Razorpay path ────────────────────────────────────────────
    const order = await razorpay.orders.create({
      amount:   totalAmount * 100,   // must be in paise (integer)
      currency: 'INR',
      receipt:  `rcpt_${Date.now()}`,
      notes:    { rideId, seats: seatsBooked, userId: req.session.userId }
    });

    // Create booking record tied to this Razorpay order
    const booking = await Booking.create({
      ride: rideId, passenger: req.session.userId,
      seatsBooked, totalAmount,
      paymentMethod: 'online', paymentStatus: 'pending',
      bookingStatus: 'pending',
      razorpayOrderId: order.id
    });

    const user = await User.findById(req.session.userId).select('name email phone');

    return res.render('bookings/payment', {
      title:    'Complete Payment',
      booking,
      ride,
      order,
      rzpKeyId: process.env.RAZORPAY_KEY_ID,
      user
    });

  } catch (err) {
    req.flash('error', err.message);
    res.redirect('/rides');
  }
};

// ── POST /bookings/verify-payment ────────────────────────────────────────────
// Called by the hidden form after Razorpay handler fires in the browser
export const verifyPayment = async (req, res) => {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      bookingId
    } = req.body;

    // Guard: missing fields
    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !bookingId) {
      req.flash('error', '❌ Invalid payment response. Please try again.');
      return res.redirect('/rides');
    }

    // ── HMAC-SHA256 signature verification ──────────────────────────────
    const expectedSig = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');

    if (expectedSig !== razorpay_signature) {
      await Booking.findByIdAndUpdate(bookingId, {
        paymentStatus: 'failed',
        bookingStatus: 'cancelled'
      });
      req.flash('error', '❌ Payment signature mismatch. Contact support.');
      return res.redirect('/profile/my-bookings');
    }

    // ── Signature valid — mark paid ──────────────────────────────────────
    // Idempotency: if already marked paid (double-submit), skip to success
    const existingBooking = await Booking.findById(bookingId);
    if (existingBooking && existingBooking.paymentStatus === 'paid') {
      req.flash('success', '✅ Payment already confirmed!');
      return res.redirect('/profile/my-bookings');
    }

    const booking = await Booking.findByIdAndUpdate(
      bookingId,
      { paymentStatus: 'paid', razorpayPaymentId: razorpay_payment_id },
      { new: true }
    ).populate('ride');

    if (!booking) {
      req.flash('error', 'Booking not found.');
      return res.redirect('/rides');
    }

    // Notify driver via socket
    const ride      = await Ride.findById(booking.ride._id).populate('driver', 'name profileImage');
    const passenger = await User.findById(booking.passenger).select('name profileImage');

    emitBookingRequest(ride.driver._id.toString(), {
      bookingId:     booking._id.toString(),
      passengerName: passenger.name,
      passengerImg:  passenger.profileImage,
      seatsBooked:   booking.seatsBooked,
      totalAmount:   booking.totalAmount,
      paymentMethod: 'online',
      rideId:        ride._id.toString(),
      source:        ride.source.name,
      destination:   ride.destination.name
    });
    await pushPendingCount(ride.driver._id);

    req.flash('success', '✅ Payment successful! Waiting for driver approval.');
    return res.redirect('/profile/my-bookings');

  } catch (err) {
    req.flash('error', err.message);
    res.redirect('/profile/my-bookings');
  }
};

// ── POST /bookings/payment-failed ────────────────────────────────────────────
// Fired when user dismisses Razorpay modal without paying
export const paymentFailed = async (req, res) => {
  try {
    const { bookingId, rideId } = req.body;
    if (bookingId) {
      await Booking.findByIdAndUpdate(bookingId, {
        paymentStatus: 'failed',
        bookingStatus: 'cancelled'
      });
    }
    req.flash('error', '❌ Payment was cancelled. You can try again.');
    // Redirect back to the ride so user can retry immediately
    return res.redirect(rideId ? `/rides/${rideId}` : '/rides');
  } catch (err) {
    res.redirect('/rides');
  }
};

// ── DELETE /bookings/:id — passenger cancels ─────────────────────────────────
export const cancelBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate('ride');
    if (!booking) { req.flash('error', 'Booking not found.'); return res.redirect('/profile/my-bookings'); }
    if (booking.passenger.toString() !== req.session.userId.toString()) {
      req.flash('error', 'Unauthorized action.'); return res.redirect('/profile/my-bookings');
    }
    if (booking.bookingStatus === 'cancelled') {
      req.flash('error', 'Booking already cancelled.'); return res.redirect('/profile/my-bookings');
    }
    if (new Date(booking.ride.date) < new Date()) {
      req.flash('error', 'Cannot cancel a past ride.'); return res.redirect('/profile/my-bookings');
    }

    if (booking.bookingStatus === 'confirmed') {
      await Ride.findByIdAndUpdate(booking.ride._id, { $inc: { availableSeats: booking.seatsBooked } });
      const updated = await Ride.findById(booking.ride._id);
      emitRideUpdate(booking.ride._id.toString(), { status: updated.status, availableSeats: updated.availableSeats });
    }

    booking.bookingStatus = 'cancelled';
    booking.cancelledBy   = 'passenger';
    booking.cancelledAt   = new Date();
    if (booking.paymentStatus === 'paid') booking.paymentStatus = 'refunded';
    await booking.save();

    await pushPendingCount(booking.ride.driver);

    req.flash('success', 'Booking cancelled successfully.');
    res.redirect('/profile/my-bookings');
  } catch (err) {
    req.flash('error', err.message); res.redirect('/profile/my-bookings');
  }
};

// ── POST /bookings/:id/confirm-payment — driver marks cash as received ───────
export const confirmPayment = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate('ride');
    if (!booking) { req.flash('error', 'Booking not found.'); return res.redirect('/profile/my-rides'); }
    if (booking.ride.driver.toString() !== req.session.userId.toString()) {
      req.flash('error', 'Unauthorized action.'); return res.redirect('/profile/my-rides');
    }
    booking.paymentStatus = 'paid';
    await booking.save();
    req.flash('success', 'Cash payment confirmed! ✅');
    res.redirect('/profile/my-rides');
  } catch (err) {
    req.flash('error', err.message); res.redirect('/profile/my-rides');
  }
};
