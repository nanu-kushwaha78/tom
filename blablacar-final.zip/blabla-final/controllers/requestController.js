// ─── ES Module: controllers/requestController.js ──────────────────────────
// Handles driver's ability to view, accept, and reject booking requests
import Booking from '../models/Booking.js';
import Ride    from '../models/Ride.js';
import {
  emitRideUpdate,
  emitBookingResponse,
  emitNotificationCount
} from '../socket.js';

// ── Helper ──────────────────────────────────────────────────────────────────
async function pushPendingCount(driverUserId) {
  const myRideIds = await Ride.find({ driver: driverUserId }).distinct('_id');
  const count = await Booking.countDocuments({
    ride:          { $in: myRideIds },
    bookingStatus: 'pending'
  });
  emitNotificationCount(driverUserId.toString(), count);
}

// GET /requests — Driver sees all pending requests for their rides
export const getRequests = async (req, res) => {
  try {
    const myRideIds = await Ride.find({ driver: req.session.userId }).distinct('_id');

    const pending = await Booking.find({
      ride:          { $in: myRideIds },
      bookingStatus: 'pending'
    })
      .populate('passenger', 'name email phone profileImage')
      .populate('ride', 'source destination date time price availableSeats')
      .sort({ createdAt: -1 });

    const history = await Booking.find({
      ride:          { $in: myRideIds },
      bookingStatus: { $in: ['confirmed', 'rejected', 'cancelled'] }
    })
      .populate('passenger', 'name email phone profileImage')
      .populate('ride', 'source destination date time price')
      .sort({ updatedAt: -1 })
      .limit(30);

    res.render('requests/index', {
      title: 'Manage Requests',
      pending,
      history
    });
  } catch (err) {
    next(err);
  }
};

// POST /requests/:id/accept — Driver accepts a booking request
export const acceptRequest = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate('ride');

    if (!booking) {
      req.flash('error', 'Booking not found.');
      return res.redirect('/requests');
    }
    if (booking.ride.driver.toString() !== req.session.userId.toString()) {
      req.flash('error', 'Unauthorized.');
      return res.redirect('/requests');
    }
    if (booking.bookingStatus !== 'pending') {
      req.flash('error', 'This request has already been responded to.');
      return res.redirect('/requests');
    }
    if (booking.seatsBooked > booking.ride.availableSeats) {
      req.flash('error', 'Not enough seats available anymore.');
      return res.redirect('/requests');
    }

    // Confirm booking & reduce seats
    booking.bookingStatus = 'confirmed';
    booking.respondedAt   = new Date();
    await booking.save();

    await Ride.findByIdAndUpdate(booking.ride._id, {
      $inc: { availableSeats: -booking.seatsBooked }
    });

    const updatedRide = await Ride.findById(booking.ride._id);

    // ── Socket: tell passenger their request was accepted ─────────────
    emitBookingResponse(booking.passenger.toString(), booking._id.toString(), 'confirmed');

    // ── Socket: broadcast seat update to everyone watching this ride ──
    emitRideUpdate(booking.ride._id.toString(), {
      status:         updatedRide.status,
      availableSeats: updatedRide.availableSeats
    });

    // Update driver's badge count
    await pushPendingCount(req.session.userId);

    req.flash('success', `✅ Booking accepted for ${booking.seatsBooked} seat(s).`);
    res.redirect('/requests');
  } catch (err) {
    req.flash('error', err.message);
    res.redirect('/requests');
  }
};

// POST /requests/:id/reject — Driver rejects a booking request
export const rejectRequest = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate('ride');

    if (!booking) {
      req.flash('error', 'Booking not found.');
      return res.redirect('/requests');
    }
    if (booking.ride.driver.toString() !== req.session.userId.toString()) {
      req.flash('error', 'Unauthorized.');
      return res.redirect('/requests');
    }
    if (booking.bookingStatus !== 'pending') {
      req.flash('error', 'This request has already been responded to.');
      return res.redirect('/requests');
    }

    booking.bookingStatus = 'rejected';
    booking.respondedAt   = new Date();
    await booking.save();

    // ── Socket: tell passenger their request was rejected ─────────────
    emitBookingResponse(booking.passenger.toString(), booking._id.toString(), 'rejected');

    // Update driver's badge count
    await pushPendingCount(req.session.userId);

    req.flash('success', '❌ Booking request rejected.');
    res.redirect('/requests');
  } catch (err) {
    req.flash('error', err.message);
    res.redirect('/requests');
  }
};
