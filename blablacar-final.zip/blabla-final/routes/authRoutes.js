// ─── ES Module: routes/authRoutes.js ──────────────────────────────────────
import { Router } from 'express';
import { getSignup, postSignup, getLogin, postLogin, logout } from '../controllers/authController.js';
import { isGuest } from '../middlewares/authMiddleware.js';

const router = Router();

router.get('/signup',  isGuest, getSignup);
router.post('/signup', isGuest, postSignup);
router.get('/login',   isGuest, getLogin);
router.post('/login',  isGuest, postLogin);
router.post('/logout', logout);

export default router;
