// ─── ES Module: routes/rideRoutes.js ──────────────────────────────────────
import { Router } from 'express';
import {
  getAllRides,
  getNewRide,
  createRide,
  getRideDetails,
  cancelRide
} from '../controllers/rideController.js';
import { isAuthenticated, isDriver } from '../middlewares/authMiddleware.js';

const router = Router();

router.get('/',     getAllRides);
router.get('/new',  isAuthenticated, isDriver, getNewRide);
router.post('/',    isAuthenticated, isDriver, createRide);
router.get('/:id',  getRideDetails);
router.delete('/:id', isAuthenticated, isDriver, cancelRide);

export default router;
