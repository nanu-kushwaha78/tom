// ─── ES Module: routes/requestRoutes.js ───────────────────────────────────
import { Router } from 'express';
import { getRequests, acceptRequest, rejectRequest } from '../controllers/requestController.js';
import { isAuthenticated, isDriver } from '../middlewares/authMiddleware.js';

const router = Router();

router.get('/',              isAuthenticated, isDriver, getRequests);
router.post('/:id/accept',   isAuthenticated, isDriver, acceptRequest);
router.post('/:id/reject',   isAuthenticated, isDriver, rejectRequest);

export default router;
