// ─── ES Module: routes/bookingRoutes.js ───────────────────────────────────
import { Router } from 'express';
import {
  createBooking,
  verifyPayment,
  paymentFailed,
  cancelBooking,
  confirmPayment
} from '../controllers/bookingController.js';
import { isAuthenticated } from '../middlewares/authMiddleware.js';

const router = Router();

// Static routes MUST come before dynamic /:id routes
router.post('/',                    isAuthenticated, createBooking);

// ⚠️ No isAuthenticated on these two — Razorpay POSTs back in a new
//    navigation context and the session cookie may not survive the
//    Razorpay iframe/redirect. Security is the bookingId + HMAC signature.
router.post('/verify-payment',      verifyPayment);
router.post('/payment-failed',      paymentFailed);

router.post('/:id/confirm-payment', isAuthenticated, confirmPayment);
router.delete('/:id',               isAuthenticated, cancelBooking);

export default router;
