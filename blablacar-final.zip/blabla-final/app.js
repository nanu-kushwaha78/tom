import 'dotenv/config';
import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import mongoose from 'mongoose';
import session from 'express-session';
import flash from 'connect-flash';
import methodOverride from 'method-override';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { attachSocket } from './socket.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = dirname(__filename);

const app        = express();
const httpServer = createServer(app);          
const io         = new Server(httpServer);     
attachSocket(io);
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log(' MongoDB connected'))
  .catch(err => console.error(' MongoDB error:', err));

// ─── View Engine ───────────────────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'views'));

// ─── Middleware ────────────────────────────────────────────────────────────
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride('_method'));
app.use(express.static(join(__dirname, 'public')));

app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: true,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24, httpOnly: true, sameSite: 'lax' }
}));

app.use(flash());

// ─── Global Template Variables ─────────────────────────────────────────────
import Booking from './models/Booking.js';

app.use(async (req, res, next) => {
  res.locals.currentUser     = req.session.userId || null;
  res.locals.currentUserData = req.session.user   || null;
  res.locals.success         = req.flash('success');
  res.locals.error           = req.flash('error');

  // Pending booking requests count (for navbar badge)
  res.locals.pendingCount = 0;
  if (req.session.userId) {
    try {
      const { default: Ride } = await import('./models/Ride.js');
      const myRideIds = await Ride.find({ driver: req.session.userId }).distinct('_id');
      res.locals.pendingCount = await Booking.countDocuments({
        ride:          { $in: myRideIds },
        bookingStatus: 'pending'
      });
    } catch (_) {}
  }
  next();
});

// ─── Routes ────────────────────────────────────────────────────────────────
import indexRoutes    from './routes/indexRoutes.js';
import authRoutes     from './routes/authRoutes.js';
import profileRoutes  from './routes/profileRoutes.js';
import rideRoutes     from './routes/rideRoutes.js';
import bookingRoutes  from './routes/bookingRoutes.js';
import requestRoutes  from './routes/requestRoutes.js';

app.use('/',          indexRoutes);
app.use('/auth',      authRoutes);
app.use('/profile',   profileRoutes);
app.use('/rides',     rideRoutes);
app.use('/bookings',  bookingRoutes);
app.use('/requests',  requestRoutes);   // ← new: manage booking requests

// ─── 404 & Error ──────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).render('404', { title: 'Page Not Found' });
});
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', { title: 'Server Error', message: err.message });
});

// ─── Start (use httpServer, not app.listen) ────────────────────────────────
const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => {
  console.log(` BlaBla + Socket.IO running at http://localhost:${PORT}`);
});
