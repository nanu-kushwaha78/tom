// ─── ES Module: routes/profileRoutes.js ───────────────────────────────────
import { Router } from 'express';
import {
  getProfile,
  getEditProfile,
  updateProfile,
  getMyBookings,
  getMyRides
} from '../controllers/profileController.js';
import { isAuthenticated } from '../middlewares/authMiddleware.js';
import upload from '../middlewares/uploadMiddleware.js';

const router = Router();

router.get('/',            isAuthenticated, getProfile);
router.get('/edit',        isAuthenticated, getEditProfile);
router.put('/edit',        isAuthenticated, upload.single('profileImage'), updateProfile);
router.get('/my-bookings', isAuthenticated, getMyBookings);
router.get('/my-rides',    isAuthenticated, getMyRides);

export default router;
